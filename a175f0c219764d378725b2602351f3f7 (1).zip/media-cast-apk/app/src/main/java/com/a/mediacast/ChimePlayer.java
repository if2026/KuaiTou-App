package com.a.mediacast;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

/**
 * 代码合成的清脆风铃 / 八音盒叮当声，不引用任何现成曲调，也不打包音频文件。
 * 由高频基频叠加非谐泛音、指数衰减包络，多个钟音错落敲击形成余韵，约 2.5 秒。
 */
public class ChimePlayer implements FestivalSound {

    private static final int SAMPLE_RATE = 22050;
    private static final double TOTAL = 2.5;

    /** 敲击事件：{起始秒, 频率Hz, 振幅, 衰减率}。分解和弦式错落叮当，不构成旋律乐句。 */
    private static final double[][] EVENTS = {
            {0.00, 523.25, 0.40, 1.40},  // C5
            {0.18, 783.99, 0.36, 1.50},  // G5
            {0.36, 1318.51, 0.28, 1.60}, // E6
            {0.55, 659.25, 0.34, 1.30},  // E5
            {0.74, 1046.50, 0.38, 1.70}, // C6
            {0.95, 783.99, 0.28, 1.40},  // G5
            {1.15, 523.25, 0.24, 1.20},  // C5
            {1.35, 1318.51, 0.24, 1.60}  // E6
    };

    private AudioTrack track;
    private Thread thread;
    private volatile boolean playing;
    private Runnable onFinish;

    public boolean isPlaying() {
        return playing;
    }

    public void setOnFinish(Runnable r) {
        this.onFinish = r;
    }

    public synchronized void play() {
        if (playing) return;
        playing = true;
        thread = new Thread(this::render, "chime-player");
        thread.start();
    }

    public synchronized void pause() {
        playing = false;
        releaseTrack();
        if (thread != null) thread.interrupt();
    }

    public synchronized void release() {
        playing = false;
        releaseTrack();
        if (thread != null) thread.interrupt();
        thread = null;
    }

    private void releaseTrack() {
        if (track != null) {
            try {
                track.stop();
            } catch (IllegalStateException ignored) {
            }
            try {
                track.release();
            } catch (IllegalStateException ignored) {
            }
            track = null;
        }
    }

    private void render() {
        int total = (int) Math.round(TOTAL * SAMPLE_RATE);
        short[] pcm = new short[total];

        for (double[] e : EVENTS) {
            int start = (int) Math.round(e[0] * SAMPLE_RATE);
            double freq = e[1];
            double amp = e[2];
            double decay = e[3];
            int attack = Math.max(1, SAMPLE_RATE / 200); // 约 5ms 起音
            for (int i = start; i < total; i++) {
                double t = (i - start) / (double) SAMPLE_RATE;
                double env = Math.exp(-t * decay);
                double attackEnv = Math.min(1.0, (double) (i - start) / attack);
                // 钟音：基频 + 二次泛音 + 非谐泛音，各自不同衰减。
                double bell = Math.sin(2 * Math.PI * freq * t)
                        + 0.5 * Math.sin(2 * Math.PI * 2.0 * freq * t) * Math.exp(-t * decay * 2)
                        + 0.25 * Math.sin(2 * Math.PI * 2.76 * freq * t) * Math.exp(-t * decay * 3);
                pcm[i] += (short) (amp * env * attackEnv * bell * Short.MAX_VALUE);
            }
        }

        // 限幅，避免多音叠加削波。
        for (int i = 0; i < total; i++) {
            if (pcm[i] > Short.MAX_VALUE) pcm[i] = Short.MAX_VALUE;
            else if (pcm[i] < -Short.MAX_VALUE) pcm[i] = -Short.MAX_VALUE;
        }

        int bufSize = pcm.length * 2;
        track = new AudioTrack(AudioManager.STREAM_MUSIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                bufSize, AudioTrack.MODE_STATIC);
        boolean completed;
        try {
            track.write(pcm, 0, pcm.length);
            track.play();
            while (playing) {
                if (track.getPlaybackHeadPosition() >= total) break;
                try {
                    Thread.sleep(40);
                } catch (InterruptedException ex) {
                    break;
                }
            }
        } catch (Exception ignored) {
        } finally {
            completed = playing;
            playing = false;
            releaseTrack();
            if (completed && onFinish != null) onFinish.run();
        }
    }
}
