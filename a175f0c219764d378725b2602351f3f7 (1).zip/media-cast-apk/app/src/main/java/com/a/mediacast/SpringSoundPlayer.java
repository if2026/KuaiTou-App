package com.a.mediacast;

import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;

/**
 * 春节专属合成音效：原创高频金属碰击（金币叮当）错落几声，收尾一声敲钟。
 * 纯 PCM 代码合成，不打包音频文件，不复刻任何现有游戏 / 影视音效或旋律。
 */
public class SpringSoundPlayer implements FestivalSound {

    private static final int SAMPLE_RATE = 22050;
    private static final double TOTAL = 2.4;

    /** 事件：{起始秒, 频率Hz, 振幅, 衰减率, 类型(0=金属碰击, 1=敲钟)}。 */
    private static final double[][] EVENTS = {
            {0.00, 1318.51, 0.30, 5.0, 0}, // E6 碰击
            {0.15, 1567.98, 0.28, 5.0, 0}, // G6 碰击
            {0.30, 2093.00, 0.24, 5.5, 0}, // C7 碰击
            {0.46, 1318.51, 0.26, 4.5, 0}, // E6 碰击
            {0.70, 1046.50, 0.40, 1.5, 1}, // C6 敲钟收尾
            {1.05, 1567.98, 0.22, 5.0, 0}  // G6 点缀碰击
    };

    private AudioTrack track;
    private Thread thread;
    private volatile boolean playing;
    private Runnable onFinish;

    @Override
    public boolean isPlaying() {
        return playing;
    }

    @Override
    public void setOnFinish(Runnable r) {
        this.onFinish = r;
    }

    @Override
    public synchronized void play() {
        if (playing) return;
        playing = true;
        thread = new Thread(this::render, "spring-sound");
        thread.start();
    }

    @Override
    public synchronized void pause() {
        playing = false;
        releaseTrack();
        if (thread != null) thread.interrupt();
    }

    @Override
    public synchronized void release() {
        playing = false;
        releaseTrack();
        if (thread != null) thread.interrupt();
        thread = null;
    }

    private void releaseTrack() {
        if (track != null) {
            try {
                track.stop();
            } catch (IllegalStateException ignored) {
            }
            try {
                track.release();
            } catch (IllegalStateException ignored) {
            }
            track = null;
        }
    }

    private void render() {
        int total = (int) Math.round(TOTAL * SAMPLE_RATE);
        short[] pcm = new short[total];

        for (double[] e : EVENTS) {
            int start = (int) Math.round(e[0] * SAMPLE_RATE);
            double freq = e[1];
            double amp = e[2];
            double decay = e[3];
            boolean bell = e[4] == 1;
            int attack = Math.max(1, SAMPLE_RATE / 200);
            for (int i = start; i < total; i++) {
                double t = (i - start) / (double) SAMPLE_RATE;
                double env = Math.exp(-t * decay);
                double attackEnv = Math.min(1.0, (double) (i - start) / attack);
                double tone;
                if (bell) {
                    tone = Math.sin(2 * Math.PI * freq * t)
                            + 0.5 * Math.sin(2 * Math.PI * 2.0 * freq * t) * Math.exp(-t * decay * 2)
                            + 0.25 * Math.sin(2 * Math.PI * 2.76 * freq * t) * Math.exp(-t * decay * 3);
                } else {
                    // 金属碰击：基频 + 较高非谐泛音，快速衰减。
                    tone = Math.sin(2 * Math.PI * freq * t)
                            + 0.6 * Math.sin(2 * Math.PI * 2.76 * freq * t) * Math.exp(-t * decay * 1.5);
                }
                pcm[i] += (short) (amp * env * attackEnv * tone * Short.MAX_VALUE);
            }
        }

        for (int i = 0; i < total; i++) {
            if (pcm[i] > Short.MAX_VALUE) pcm[i] = Short.MAX_VALUE;
            else if (pcm[i] < -Short.MAX_VALUE) pcm[i] = -Short.MAX_VALUE;
        }

        int bufSize = pcm.length * 2;
        track = new AudioTrack(AudioManager.STREAM_MUSIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT,
                bufSize, AudioTrack.MODE_STATIC);
        boolean completed;
        try {
            track.write(pcm, 0, pcm.length);
            track.play();
            while (playing) {
                if (track.getPlaybackHeadPosition() >= total) break;
                try {
                    Thread.sleep(40);
                } catch (InterruptedException ex) {
                    break;
                }
            }
        } catch (Exception ignored) {
        } finally {
            completed = playing;
            playing = false;
            releaseTrack();
            if (completed && onFinish != null) onFinish.run();
        }
    }
}
