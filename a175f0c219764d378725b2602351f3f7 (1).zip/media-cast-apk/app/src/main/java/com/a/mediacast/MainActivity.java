package com.a.mediacast;

import android.Manifest;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.ColorStateList;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.HapticFeedbackConstants;
import android.view.View;
import android.widget.AbsListView;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.view.WindowInsetsControllerCompat;

import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    private static final int REQ_MEDIA = 100;
    private static final int HTTP_PORT = 8973;

    private MediaHttpServer server;
    private final DmrController controller = new DmrController();
    private final SsdpDiscovery discovery = new SsdpDiscovery();

    private final List<DmrDevice> devices = new ArrayList<>();
    private final List<MediaItem> mediaItems = new ArrayList<>();
    private ArrayAdapter<String> deviceAdapter;
    private MediaAdapter mediaAdapter;

    private DmrDevice selectedDevice;
    private String currentKind = "video";
    /** 本地记录的播放状态：idle / playing / paused / stopped，用于避免重复发暂停并给引导提示。 */
    private String playbackState = "idle";

    private static final int PAGE_SIZE = 50;
    private int currentOffset = 0;
    private boolean loadingPage = false;
    private boolean hasMore = true;
    private boolean scanning = false;

    private TextView statusText;
    private TextView appTitle;
    private ListView deviceList;
    private ListView mediaList;
    private Button tabVideo, tabImage, tabAudio;
    private Button btnScan, btnWebCast;
    private ImageView btnMusic;
    private FestivalSound soundPlayer;
    private FestivalTheme.Festival festival = FestivalTheme.Festival.NONE;

    private final Handler main = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        View root = findViewById(R.id.root_layout);
        View controlBar = findViewById(R.id.control_bar);
        // edge-to-edge：深色背景延伸到状态栏/导航栏下方；图标保持白色。
        WindowCompat.setDecorFitsSystemWindows(getWindow(), false);
        new WindowInsetsControllerCompat(getWindow(), root).setAppearanceLightStatusBars(false);
        ViewCompat.setOnApplyWindowInsetsListener(root, (v, insets) -> {
            int top = insets.getInsets(WindowInsetsCompat.Type.statusBars()).top;
            int bottom = insets.getInsets(WindowInsetsCompat.Type.navigationBars()).bottom;
            int pad = dp(18);
            root.setPadding(pad, pad + top, pad, pad);
            controlBar.setPadding(0, 0, 0, dp(12) + bottom);
            return insets;
        });

        statusText = findViewById(R.id.status_text);
        appTitle = findViewById(R.id.app_title);
        deviceList = findViewById(R.id.device_list);
        mediaList = findViewById(R.id.media_list);
        tabVideo = findViewById(R.id.tab_video);
        tabImage = findViewById(R.id.tab_image);
        tabAudio = findViewById(R.id.tab_audio);

        deviceAdapter = new ArrayAdapter<>(this,
                android.R.layout.simple_list_item_single_choice, new ArrayList<>());
        deviceList.setAdapter(deviceAdapter);
        deviceList.setOnItemClickListener((parent, view, position, id) -> {
            DmrDevice d = devices.get(position);
            if (!d.isRenderer()) {
                toast("这台不是可投屏设备，请选择标注「可投屏」的设备");
                return;
            }
            selectedDevice = d;
            playbackState = "idle";
            deviceList.setItemChecked(position, true);
            String note = d.parseNote == null ? "" : "（" + d.parseNote + "）";
            setStatus("已选：" + d.displayName() + " · " + d.badge() + note);
        });

        mediaAdapter = new MediaAdapter(this, mediaItems);
        mediaList.setAdapter(mediaAdapter);
        mediaList.setOnItemClickListener((parent, view, position, id) ->
                castItem(mediaItems.get(position)));
        mediaList.setOnScrollListener(new AbsListView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(AbsListView view, int scrollState) {
                boolean idle = scrollState == SCROLL_STATE_IDLE;
                mediaAdapter.setScrolling(!idle);
                if (idle) {
                    // 停稳后补载当前可见、尚未缓存的缩略图。
                    mediaAdapter.notifyDataSetChanged();
                    maybeLoadNextPage();
                }
            }

            @Override
            public void onScroll(AbsListView view, int firstVisible, int visibleCount, int totalCount) {
                if (totalCount > 0 && firstVisible + visibleCount >= totalCount) {
                    maybeLoadNextPage();
                }
            }
        });

        festival = FestivalTheme.today();
        if (festival == FestivalTheme.Festival.CHRISTMAS) {
            soundPlayer = new ChimePlayer();
        } else if (festival == FestivalTheme.Festival.SPRING) {
            soundPlayer = new SpringSoundPlayer();
        } else {
            soundPlayer = null;
        }
        if (soundPlayer != null) {
            soundPlayer.setOnFinish(() -> main.post(() -> setMusicPlaying(false)));
        }
        btnScan = findViewById(R.id.btn_scan);
        btnWebCast = findViewById(R.id.btn_web_cast);
        btnMusic = findViewById(R.id.btn_music);
        btnMusic.setVisibility(festival == FestivalTheme.Festival.CHRISTMAS
                || festival == FestivalTheme.Festival.SPRING
                ? View.VISIBLE : View.GONE);
        btnMusic.setOnClickListener(v -> toggleMusic());
        findViewById(R.id.btn_menu).setOnClickListener(this::showPopupMenu);
        btnScan.setOnClickListener(v -> { tap(v); scanDevices(); });
        findViewById(R.id.btn_play).setOnClickListener(v -> { tap(v); control("play"); });
        findViewById(R.id.btn_pause).setOnClickListener(v -> { tap(v); control("pause"); });
        findViewById(R.id.btn_stop).setOnClickListener(v -> { tap(v); control("stop"); });
        btnWebCast.setOnClickListener(v -> openWeb(null));

        tabVideo.setOnClickListener(v -> switchKind("video", tabVideo));
        tabImage.setOnClickListener(v -> switchKind("image", tabImage));
        tabAudio.setOnClickListener(v -> switchKind("audio", tabAudio));
        refreshTabs();
        applyFestivalTheme();
        showFestivalGreeting();

        ensurePermissions();
    }

    // ===== 权限 =====

    private String[] requiredPermissions() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            return new String[] {
                    Manifest.permission.READ_MEDIA_VIDEO,
                    Manifest.permission.READ_MEDIA_IMAGES,
                    Manifest.permission.READ_MEDIA_AUDIO
            };
        }
        return new String[] { Manifest.permission.READ_EXTERNAL_STORAGE };
    }

    private void ensurePermissions() {
        String[] perms = requiredPermissions();
        boolean granted = true;
        for (String p : perms) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) granted = false;
        }
        if (granted) {
            onPermissionsReady();
        } else {
            requestPermissions(perms, REQ_MEDIA);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        boolean granted = grantResults.length > 0;
        for (int r : grantResults) {
            if (r != PackageManager.PERMISSION_GRANTED) granted = false;
        }
        if (granted) {
            onPermissionsReady();
        } else {
            setStatus("缺少媒体读取权限，无法列出本地文件");
        }
    }

    private void onPermissionsReady() {
        server = new MediaHttpServer(this, HTTP_PORT);
        server.start();
        setStatus("本地服务已启动：" + server.baseUrl());
        loadMedia();
    }

    // ===== 设备扫描 =====

    private void scanDevices() {
        if (scanning) return;
        scanning = true;
        setStatus("正在扫描同 WiFi 下的投屏设备…");
        // 每次扫描刷新列表，避免上一轮的失效/幽灵条目残留。
        devices.clear();
        deviceAdapter.clear();
        deviceList.clearChoices();
        selectedDevice = null;
        playbackState = "idle";
        discovery.scan(this, new SsdpDiscovery.Listener() {
            @Override
            public void onDeviceFound(DmrDevice device) {
                main.post(() -> {
                    for (DmrDevice d : devices) {
                        if (d.usn.equals(device.usn)) return;
                    }
                    devices.add(device);
                    deviceAdapter.add(device.toString());
                    // 不自动选中设备：初始一律不打勾，由用户手动点选哪台才勾哪台。
                    setStatus("发现设备：" + device.displayName() + "（" + device.badge() + "）");
                });
            }

            @Override
            public void onScanFinished() {
                main.post(() -> {
                    scanning = false;
                    if (devices.isEmpty()) {
                        setStatus("未发现可投屏设备，请确认电视/盒子已开机并连接同一 WiFi");
                    } else {
                        setStatus("扫描完成，共发现 " + devices.size() + " 台设备");
                    }
                });
            }
        });
    }

    // ===== 媒体列表 =====

    private void switchKind(String kind, Button tab) {
        currentKind = kind;
        refreshTabs();
        loadMedia();
    }

    /** 刷新三个分类按钮的选中态：关闭 Material 背景着色，同步背景与文字颜色；节日期选中色跟随主题。 */
    private void refreshTabs() {
        Button[] tabs = {tabVideo, tabImage, tabAudio};
        String[] kinds = {"video", "image", "audio"};
        int festPrimary = festival == FestivalTheme.Festival.NONE ? 0
                : FestivalTheme.primaryColor(festival);
        for (int i = 0; i < tabs.length; i++) {
            boolean on = kinds[i].equals(currentKind);
            tabs[i].setBackgroundTintList(null);
            tabs[i].setBackgroundResource(on ? R.drawable.btn_accent : R.drawable.btn_round);
            if (on && festPrimary != 0) {
                tabs[i].setBackgroundTintList(ColorStateList.valueOf(festPrimary));
            }
            tabs[i].setTextColor(getColor(on ? R.color.bg : R.color.text_primary));
        }
    }

    private void loadMedia() {
        currentOffset = 0;
        hasMore = true;
        loadingPage = false;
        background(() -> {
            List<MediaItem> result = MediaStoreReader.loadPage(this, currentKind, 0, PAGE_SIZE);
            main.post(() -> {
                mediaItems.clear();
                mediaItems.addAll(result);
                hasMore = result.size() >= PAGE_SIZE;
                currentOffset = result.size();
                mediaAdapter.notifyDataSetChanged();
                if (result.isEmpty()) setStatus("当前分类下没有可用媒体");
            });
        });
    }

    private void maybeLoadNextPage() {
        if (!loadingPage && hasMore) loadNextPage();
    }

    private void loadNextPage() {
        loadingPage = true;
        background(() -> {
            List<MediaItem> result = MediaStoreReader.loadPage(this, currentKind, currentOffset, PAGE_SIZE);
            main.post(() -> {
                loadingPage = false;
                mediaItems.addAll(result);
                hasMore = result.size() >= PAGE_SIZE;
                currentOffset += result.size();
                mediaAdapter.notifyDataSetChanged();
            });
        });
    }

    // ===== 推送与控制 =====

    private void castItem(MediaItem item) {
        if (selectedDevice == null) {
            toast("请先扫描并选择一台投屏设备");
            return;
        }
        if (!selectedDevice.isRenderer()) {
            toast("「" + selectedDevice.displayName() + "」是" + selectedDevice.badge()
                    + "，请选标注「可投屏」的设备");
            return;
        }
        String url = server.urlFor(item);
        setStatus("正在推送：" + item.title);
        background(() -> {
            String err = controller.cast(selectedDevice, url, item.title,
                    item.mimeType, item.kind);
            main.post(() -> {
                if (err == null) {
                    playbackState = "playing";
                    setStatus("已推送并播放：" + item.title);
                    toast("已投放到 " + selectedDevice.name);
                } else {
                    setStatus("推送失败：" + err);
                    toast("推送失败：" + err);
                }
            });
        });
    }

    private void control(String action) {
        if (selectedDevice == null) {
            toast("请先选择投屏设备");
            return;
        }
        String actionCn = actionCn(action);

        // 本地已是暂停状态，再点暂停不重复发指令，直接引导继续播放。
        if ("pause".equals(action) && "paused".equals(playbackState)) {
            setStatus("已暂停，点「播放」可继续");
            toast("已暂停，点「播放」可继续");
            return;
        }

        background(() -> {
            String err;
            switch (action) {
                case "play": err = controller.play(selectedDevice); break;
                case "pause": err = controller.pause(selectedDevice); break;
                default: err = controller.stop(selectedDevice); break;
            }
            main.post(() -> {
                if (err == null) {
                    setStatus("已" + actionCn);
                    if ("play".equals(action)) playbackState = "playing";
                    else if ("pause".equals(action)) playbackState = "paused";
                    else playbackState = "stopped";
                } else if (isStateOnly(err)) {
                    // 701/703/704/715：无活动会话或当前状态不允许该动作，属状态反馈，不当错误弹窗。
                    if ("pause".equals(action)) {
                        playbackState = "paused";
                        setStatus("当前已暂停或无播放内容，点「播放」可继续");
                        toast("已暂停，点「播放」可继续");
                    } else {
                        setStatus("当前没有正在播放的内容，或状态不支持" + actionCn);
                    }
                } else {
                    setStatus("控制失败：" + err);
                    toast("控制失败：" + err);
                }
            });
        });
    }

    private String actionCn(String action) {
        switch (action) {
            case "play": return "播放";
            case "pause": return "暂停";
            default: return "停止";
        }
    }

    /** 设备反馈的状态类错误码：无活动会话 / 当前播放模式不允许 / 状态过渡不可用 / 无效传输状态。 */
    private boolean isStateOnly(String err) {
        if (err == null) return false;
        return err.contains("errorCode=701") || err.contains("errorCode=703")
                || err.contains("errorCode=704") || err.contains("errorCode=715");
    }

    // ===== 顶部下拉菜单 =====

    private void showPopupMenu(View anchor) {
        PopupMenu menu = new PopupMenu(this, anchor);
        menu.getMenuInflater().inflate(R.menu.nav_menu, menu.getMenu());
        menu.setOnMenuItemClickListener(item -> {
            tap(anchor);
            if (item.getItemId() == R.id.action_web_cast) {
                openWeb(null);
                return true;
            }
            if (item.getItemId() == R.id.action_url_cast) {
                showUrlCastDialog();
                return true;
            }
            return false;
        });
        menu.show();
    }

    // ===== URL 直链投屏 =====

    private void showUrlCastDialog() {
        final EditText input = new EditText(this);
        input.setHint("https://example.com/video.mp4");
        input.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        int pad = (int) (16 * getResources().getDisplayMetrics().density);
        input.setPadding(pad, pad, pad, pad);
        new AlertDialog.Builder(this)
                .setTitle("URL 直链投屏")
                .setView(input)
                .setPositiveButton("投屏", (d, w) -> castDirectUrl(input.getText().toString()))
                .setNegativeButton("取消", null)
                .show();
    }

    private void castDirectUrl(String raw) {
        String url = raw == null ? "" : raw.trim();
        if (url.isEmpty()) {
            toast("请输入视频直链");
            return;
        }
        if (url.toLowerCase().startsWith("magnet:")) {
            toast("暂不支持磁力链接，请输入 http/https 视频直链");
            return;
        }
        if (!url.startsWith("http://") && !url.startsWith("https://")) {
            url = "https://" + url;
        }
        String lower = url.toLowerCase();
        if (!isDirectVideoUrl(lower)) {
            toast("链接不是可投屏的视频格式（mp4 / m3u8 / mkv）");
            return;
        }
        if (selectedDevice == null) {
            toast("请先扫描并选择一台投屏设备");
            return;
        }
        if (!selectedDevice.isRenderer()) {
            toast("「" + selectedDevice.displayName() + "」是" + selectedDevice.badge()
                    + "，请选标注「可投屏」的设备");
            return;
        }
        String mime = guessDirectMime(lower);
        String title = titleFromUrl(url);
        String playUrl = proxyDirectUrl(url);
        setStatus("正在推送：" + title);
        background(() -> {
            String err = controller.cast(selectedDevice, playUrl, title, mime, "video");
            main.post(() -> {
                if (err == null) {
                    playbackState = "playing";
                    setStatus("已推送并播放：" + title);
                    toast("已投放到 " + selectedDevice.name);
                } else {
                    setStatus("推送失败：" + err);
                    toast("推送失败：" + err);
                }
            });
        });
    }

    private static boolean isDirectVideoUrl(String u) {
        return u.contains(".mp4") || u.contains(".m3u8") || u.contains(".mkv")
                || u.contains(".webm") || u.contains(".mov");
    }

    private static String guessDirectMime(String u) {
        if (u.contains(".m3u8")) return "application/x-mpegURL";
        if (u.contains(".webm")) return "video/webm";
        if (u.contains(".mov")) return "video/quicktime";
        if (u.contains(".mkv")) return "video/x-matroska";
        return "video/mp4";
    }

    private static String titleFromUrl(String url) {
        try {
            String u = url;
            int q = u.indexOf('?');
            if (q >= 0) u = u.substring(0, q);
            int slash = u.lastIndexOf('/');
            String name = slash >= 0 ? u.substring(slash + 1) : u;
            name = URLDecoder.decode(name, "UTF-8");
            return name.isEmpty() ? "网络直链" : name;
        } catch (Exception e) {
            return "网络直链";
        }
    }

    /** 复用本地代理中转，规避老盒子不支持 https；无 Referer 防盗链信息。 */
    private String proxyDirectUrl(String realUrl) {
        try {
            String ip = NetUtils.getLocalIpv4();
            if (ip == null || server == null) return realUrl;
            return "http://" + ip + ":" + HTTP_PORT
                    + "/proxy?url=" + URLEncoder.encode(realUrl, "UTF-8");
        } catch (Exception e) {
            return realUrl;
        }
    }

    private void openWeb(String startUrl) {
        Intent i = new Intent(this, WebCastActivity.class);
        if (selectedDevice != null) {
            i.putExtra("device_url", selectedDevice.avTransportUrl);
            i.putExtra("device_name", selectedDevice.displayName());
        }
        if (startUrl != null && !startUrl.isEmpty()) i.putExtra("start_url", startUrl);
        startActivity(i);
    }

    // ===== 节日彩蛋 =====

    private void applyFestivalTheme() {
        if (festival == FestivalTheme.Festival.NONE) return;
        int primary = FestivalTheme.primaryColor(festival);
        int secondary = FestivalTheme.secondaryColor(festival);
        appTitle.setTextColor(primary);
        statusText.setTextColor(secondary);
        btnScan.setBackgroundTintList(ColorStateList.valueOf(primary));
        btnScan.setTextColor(getColor(R.color.bg));
        btnWebCast.setBackgroundTintList(ColorStateList.valueOf(secondary));
        btnWebCast.setTextColor(getColor(R.color.bg));
    }

    private void showFestivalGreeting() {
        if (festival == FestivalTheme.Festival.NONE) return;
        new AlertDialog.Builder(this)
                .setTitle(FestivalTheme.title(festival))
                .setMessage(FestivalTheme.greeting(festival))
                .setPositiveButton("收下祝福", null)
                .show();
    }

    private void toggleMusic() {
        if (soundPlayer == null) return;
        if (soundPlayer.isPlaying()) {
            soundPlayer.pause();
            setMusicPlaying(false);
        } else {
            soundPlayer.play();
            setMusicPlaying(true);
        }
    }

    private void setMusicPlaying(boolean playing) {
        int tint = playing ? FestivalTheme.primaryColor(festival)
                : getColor(R.color.text_secondary);
        btnMusic.setImageTintList(ColorStateList.valueOf(tint));
    }

    // ===== 工具 =====

    private void setStatus(String text) {
        statusText.setText(text);
    }

    private void toast(String text) {
        Toast.makeText(this, text, Toast.LENGTH_LONG).show();
    }

    /** 极轻微短促的点击触感；系统级触觉反馈，无需震动权限。 */
    private void tap(View v) {
        if (v == null) return;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            v.performHapticFeedback(HapticFeedbackConstants.CONTEXT_CLICK);
        } else {
            v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY);
        }
    }

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private void background(Runnable r) {
        new Thread(r).start();
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (soundPlayer != null) soundPlayer.release();
        if (server != null) server.stop();
    }
}
