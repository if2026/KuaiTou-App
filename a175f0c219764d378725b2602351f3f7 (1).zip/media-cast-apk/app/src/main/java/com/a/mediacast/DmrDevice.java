package com.a.mediacast;

/**
 * 局域网内一台 UPnP/DLNA 设备。
 * isRenderer() 为 true 才是可被推送控制的渲染器（电视 / 盒子）。
 */
public class DmrDevice {

    public final String usn;
    public String name;
    public String location;
    public String serverHeader;
    /** 设备类型：MediaRenderer / MediaServer / 其他 */
    public String deviceType;
    public String modelName;
    /** 解析到的服务类型简记，便于排查 */
    public String services = "";
    /** 描述拉取 / 解析结果备注 */
    public String parseNote;

    /** AVTransport 服务的控制地址（绝对 URL） */
    public String avTransportUrl;
    /** RenderingControl 服务的控制地址（绝对 URL，可能为空） */
    public String renderControlUrl;

    public DmrDevice(String usn) {
        this.usn = usn;
    }

    public boolean isRenderer() {
        return avTransportUrl != null;
    }

    /**
     * 描述已成功拉取并解析出至少一个 UPnP 服务。
     * 描述拉取失败（404 / 不可达）或解析不出任何服务的通告属于无效响应，
     * 不应作为设备出现在列表里（没开电视也可能收到这类幽灵通告）。
     */
    public boolean isDiscoverable() {
        boolean parseOk = parseNote == null || !parseNote.startsWith("描述解析失败");
        return parseOk && !services.isEmpty();
    }

    /** 列表展示名：友好名 > 型号 > SERVER 头 > USN。 */
    public String displayName() {
        if (name != null && !name.isEmpty() && !name.startsWith("Unspecified")) return name;
        if (modelName != null && !modelName.isEmpty()) return modelName;
        if (serverHeader != null) return serverHeader;
        return usn;
    }

    public String badge() {
        if (isRenderer()) return "可投屏";
        if (deviceType != null && deviceType.contains("MediaServer")) return "媒体服务器（不可投屏）";
        return "未识别服务";
    }

    @Override
    public String toString() {
        return displayName() + " · " + badge();
    }
}
