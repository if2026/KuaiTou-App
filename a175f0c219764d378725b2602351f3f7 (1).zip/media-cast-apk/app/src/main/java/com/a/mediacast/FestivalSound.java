package com.a.mediacast;

/** 节日合成音效统一接口：纯 PCM 代码合成，不打包音频文件。 */
public interface FestivalSound {

    boolean isPlaying();

    void setOnFinish(Runnable r);

    void play();

    void pause();

    void release();
}
