package com.a.mediacast;

import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 向 DLNA 渲染设备（DMR）发送 UPnP SOAP 指令：推送媒体地址并播放 / 暂停 / 停止。
 * 所有方法均为同步阻塞，需在后台线程调用。
 */
public class DmrController {

    private static final String AVT = "urn:schemas-upnp-org:service:AVTransport:1";

    /** 推送媒体并开始播放。返回 null 表示成功，否则为错误说明。 */
    public String cast(DmrDevice device, String mediaUrl, String title,
                       String mime, String kind) {
        return cast(device, mediaUrl, title, mime, kind, null);
    }

    /**
     * 带请求头的推送重载。
     * headers 留存备用：DLNA AVTransport 标准报文不支持为播放器指定自定义请求头，
     * 带 Cookie / Referer / Token 的流，盒子直接拉地址可能 403。若要带头播放，
     * 需在手机端起本地中转代理，由代理补头后再把本地地址投给盒子。
     */
    public String cast(DmrDevice device, String mediaUrl, String title,
                       String mime, String kind, Map<String, String> headers) {
        if (device.avTransportUrl == null) {
            return "该设备未提供 AVTransport 控制地址";
        }
        // headers 当前仅留存，未写入标准 SOAP 报文（见上方说明）。
        @SuppressWarnings("unused")
        Map<String, String> retainedHeaders = headers;
        // DIDL 元数据里标明媒体类型（图片/视频/音乐）、格式与地址，
        // 否则部分盒子会把图片当视频解码，报"不能播放此视频"。
        String metadata = buildDidl(title, mime, mediaUrl, kind);
        String body = envelope("SetAVTransportURI",
                "<InstanceID>0</InstanceID>"
                        + "<CurrentURI>" + escape(mediaUrl) + "</CurrentURI>"
                        + "<CurrentURIMetaData>" + escape(metadata) + "</CurrentURIMetaData>");
        String err = post(device.avTransportUrl, "SetAVTransportURI", body);
        if (err != null) return err;
        String playBody = envelope("Play",
                "<InstanceID>0</InstanceID><Speed>1</Speed>");
        if ("image".equals(kind)) {
            // 部分盒子图片也要 Play 才显示；Play 失败/超时不阻断，Set 成功即视为已推送。
            post(device.avTransportUrl, "Play", playBody, 3000);
            return null;
        }
        return post(device.avTransportUrl, "Play", playBody, 8000);
    }

    public String play(DmrDevice device) {
        if (device.avTransportUrl == null) return "无控制地址";
        return post(device.avTransportUrl, "Play",
                envelope("Play", "<InstanceID>0</InstanceID><Speed>1</Speed>"));
    }

    public String pause(DmrDevice device) {
        if (device.avTransportUrl == null) return "无控制地址";
        return post(device.avTransportUrl, "Pause",
                envelope("Pause", "<InstanceID>0</InstanceID>"));
    }

    public String stop(DmrDevice device) {
        if (device.avTransportUrl == null) return "无控制地址";
        return post(device.avTransportUrl, "Stop",
                envelope("Stop", "<InstanceID>0</InstanceID>"));
    }

    private String post(String controlUrl, String action, String body) {
        return post(controlUrl, action, body, 8000);
    }

    private String post(String controlUrl, String action, String body, int readTimeout) {
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(controlUrl).openConnection();
            conn.setRequestMethod("POST");
            conn.setConnectTimeout(5000);
            conn.setReadTimeout(readTimeout);
            conn.setDoOutput(true);
            conn.setRequestProperty("Content-Type", "text/xml; charset=\"utf-8\"");
            conn.setRequestProperty("SOAPACTION", "\"" + AVT + "#" + action + "\"");
            conn.setRequestProperty("Connection", "close");

            OutputStream os = conn.getOutputStream();
            os.write(body.getBytes("UTF-8"));
            os.flush();

            int code = conn.getResponseCode();
            if (code >= 200 && code < 300) return null;

            InputStream errStream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            String errBody = readAll(errStream);
            String detail = parseFault(errBody);
            return action + " 返回 HTTP " + code + (detail.isEmpty() ? "" : "：" + detail);
        } catch (Exception e) {
            return action + "：" + e.getClass().getSimpleName() + ": " + e.getMessage();
        } finally {
            if (conn != null) conn.disconnect();
        }
    }

    private static String readAll(InputStream in) {
        if (in == null) return "";
        try {
            StringBuilder sb = new StringBuilder();
            byte[] buf = new byte[1024];
            int n;
            while ((n = in.read(buf)) != -1 && sb.length() < 2048) {
                sb.append(new String(buf, 0, n, "UTF-8"));
            }
            return sb.toString();
        } catch (Exception e) {
            return "";
        }
    }

    /** 从 SOAP Fault / UPnP 错误详情里抠出可读的错误码与描述。 */
    private static String parseFault(String xml) {
        if (xml == null || xml.isEmpty()) return "";
        String[] tags = {"faultstring", "errorDescription", "errorCode"};
        StringBuilder sb = new StringBuilder();
        for (String t : tags) {
            String v = tagContent(xml, t);
            if (v != null && !v.isEmpty()) {
                if (sb.length() > 0) sb.append("，");
                sb.append(t).append("=").append(v);
            }
        }
        return sb.toString();
    }

    private static String tagContent(String xml, String tag) {
        Pattern p = Pattern.compile(
                "<[A-Za-z0-9:]*" + tag + "[^>]*>(.*?)</[A-Za-z0-9:]*" + tag + ">",
                Pattern.DOTALL);
        Matcher m = p.matcher(xml);
        if (!m.find()) return null;
        return m.group(1).replaceAll("<[^>]+>", "").trim();
    }

    private static String envelope(String action, String inner) {
        return "<?xml version=\"1.0\" encoding=\"utf-8\"?>"
                + "<s:Envelope xmlns:s=\"http://schemas.xmlsoap.org/soap/envelope/\""
                + " s:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\">"
                + "<s:Body>"
                + "<u:" + action + " xmlns:u=\"" + AVT + "\">" + inner + "</u:" + action + ">"
                + "</s:Body></s:Envelope>";
    }

    private static String buildDidl(String title, String mime, String url, String kind) {
        String cls;
        switch (kind == null ? "video" : kind) {
            case "image": cls = "object.item.imageItem"; break;
            case "audio": cls = "object.item.audioItem.musicTrack"; break;
            default: cls = "object.item.videoItem"; break;
        }
        return "<DIDL-Lite xmlns=\"urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/\""
                + " xmlns:dc=\"http://purl.org/dc/elements/1.1/\""
                + " xmlns:upnp=\"urn:schemas-upnp-org:metadata-1-0/upnp/\">"
                + "<item id=\"0\" parentID=\"-1\" restricted=\"1\">"
                + "<dc:title>" + escape(title == null ? "未命名" : title) + "</dc:title>"
                + "<upnp:class>" + cls + "</upnp:class>"
                + "<res protocolInfo=\"http-get:*:" + escape(mime == null ? "*" : mime)
                + ":*\">" + escape(url) + "</res>"
                + "</item></DIDL-Lite>";
    }

    private static String escape(String s) {
        if (s == null) return "";
        return s.replace("&", "&amp;")
                .replace("<", "&lt;")
                .replace(">", "&gt;")
                .replace("\"", "&quot;");
    }
}
