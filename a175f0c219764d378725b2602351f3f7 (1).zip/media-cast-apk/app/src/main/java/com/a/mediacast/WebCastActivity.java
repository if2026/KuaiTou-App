package com.a.mediacast;

import android.app.AlertDialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;
import android.webkit.JavascriptInterface;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.appcompat.app.AppCompatActivity;

import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * 内置浏览器页面：加载网页、嗅探视频真实地址（mp4/m3u8/webm 等），
 * 复用现有 DLNA 推流逻辑投送到已选设备。
 *
 * 已知限制：
 * 1. 用 blob: / MSE / WebSocket 分片播放的播放器，拿不到真实地址；
 * 2. 带 Cookie / Referer / Token 鉴权的流，DLNA 盒子直接拉地址可能 403，
 *    标准 AVTransport 不支持为播放器指定自定义请求头；
 * 3. .m3u8 能否播放取决于盒子是否支持 HLS。
 */
public class WebCastActivity extends AppCompatActivity {

    private WebView webView;
    private EditText addressInput;
    private TextView sniffStatus;
    private TextView webCastStatus;
    private Button btnCast;

    private static final int HTTP_PORT = 8973;

    private final DmrController controller = new DmrController();
    private DmrDevice device;

    /** 嗅探到的视频候选，保持加入顺序；key 为真实地址。 */
    private final LinkedHashMap<String, SniffedVideo> found = new LinkedHashMap<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.web_cast);

        addressInput = findViewById(R.id.address_input);
        sniffStatus = findViewById(R.id.sniff_status);
        webCastStatus = findViewById(R.id.web_cast_status);
        btnCast = findViewById(R.id.btn_cast_web);
        webView = findViewById(R.id.web_view);

        // 从主界面带入已选设备；没选到则投屏时提示。
        String deviceUrl = getIntent().getStringExtra("device_url");
        String deviceName = getIntent().getStringExtra("device_name");
        if (!TextUtils.isEmpty(deviceUrl)) {
            device = new DmrDevice("web-extra");
            device.avTransportUrl = deviceUrl;
            device.name = deviceName;
        }

        setupWebView();

        findViewById(R.id.btn_go).setOnClickListener(v -> navigate());
        addressInput.setOnKeyListener((v, keyCode, event) -> {
            if (keyCode == KeyEvent.KEYCODE_ENTER && event.getAction() == KeyEvent.ACTION_UP) {
                navigate();
                return true;
            }
            return false;
        });
        btnCast.setOnClickListener(v -> castSelected());
    }

    private void setupWebView() {
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setMediaPlaybackRequiresUserGesture(true);
        // 允许 http/https 混合内容（明文已在 Manifest 放开）。
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        webView.addJavascriptInterface(new Bridge(), "MediaCastBridge");
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                addressInput.setText(url);
                injectBridgeScript();
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                if (request != null && request.getUrl() != null) {
                    sniff(request.getUrl().toString(), request.getRequestHeaders());
                }
                // 不阻断加载，只做观察。
                return null;
            }
        });
        String start = getIntent().getStringExtra("start_url");
        if (TextUtils.isEmpty(start)) {
            start = "https://www.baidu.com";
        } else if (!start.startsWith("http://") && !start.startsWith("https://")) {
            start = "https://" + start;
        }
        webView.loadUrl(start);
    }

    private void navigate() {
        String input = addressInput.getText().toString().trim();
        if (TextUtils.isEmpty(input)) return;
        if (!input.startsWith("http://") && !input.startsWith("https://")) {
            input = "https://" + input;
        }
        webView.loadUrl(input);
    }

    // ===== 视频地址嗅探 =====

    /** JS 回调接口：网页里 <video>/<source> 标签上的地址。 */
    private class Bridge {
        @JavascriptInterface
        public void onVideo(String url) {
            sniff(url, null);
        }
    }

    private synchronized void sniff(String url, Map<String, String> headers) {
        if (TextUtils.isEmpty(url)) return;
        String u = url.trim();
        if (u.startsWith("blob:")) return;
        String lower = u.toLowerCase();
        if (!isVideoUrl(lower)) return;
        if (found.containsKey(u)) return;
        found.put(u, new SniffedVideo(u, guessMime(lower),
                headers == null ? new HashMap<>() : new HashMap<>(headers)));
        runOnUiThread(() -> {
            String first = new ArrayList<>(found.keySet()).get(0);
            sniffStatus.setText("已嗅探到 " + found.size() + " 个：" + first);
        });
    }

    private static boolean isVideoUrl(String u) {
        // 注意：.ts 是 HLS 分片，数量极多且不是可直接投播的清单，这里不纳入候选。
        return u.contains(".mp4") || u.contains(".m3u8") || u.contains(".webm")
                || u.contains(".mov") || u.contains(".mkv");
    }

    private static String guessMime(String u) {
        if (u.contains(".m3u8")) return "application/x-mpegURL";
        if (u.contains(".webm")) return "video/webm";
        if (u.contains(".mov")) return "video/quicktime";
        if (u.contains(".mkv")) return "video/x-matroska";
        return "video/mp4";
    }

    /** 注入脚本：扫描 video/source 标签并监听后续插入的媒体元素。 */
    private void injectBridgeScript() {
        String js = "(function(){"
                + "function report(s){try{if(s&&s.indexOf('blob:')!==0&&window.MediaCastBridge){MediaCastBridge.onVideo(s);}}catch(e){}}"
                + "function scan(){document.querySelectorAll('video,source').forEach(function(n){report(n.currentSrc||n.src);});}"
                + "scan();"
                + "document.addEventListener('loadeddata',scan,true);"
                + "var mo=new MutationObserver(scan);"
                + "mo.observe(document.documentElement,{childList:true,subtree:true,attributes:true});"
                + "})();";
        webView.evaluateJavascript(js, null);
    }

    // ===== 投屏 =====

    private void castSelected() {
        if (device == null || !device.isRenderer()) {
            webCastStatus.setText("请先回主界面选择一台可投屏设备");
            Toast.makeText(this, "请先回主界面选择可投屏设备", Toast.LENGTH_LONG).show();
            return;
        }
        if (found.isEmpty()) {
            webCastStatus.setText("还没嗅探到视频地址，请先在页面里播放视频");
            return;
        }
        List<SniffedVideo> list = sortedCandidates();
        if (list.size() == 1) {
            castToDevice(list.get(0));
        } else {
            String[] items = new String[list.size()];
            for (int i = 0; i < list.size(); i++) items[i] = shortUrl(list.get(i).url);
            new AlertDialog.Builder(this)
                    .setTitle("选择要投屏的视频")
                    .setItems(items, (d, which) -> castToDevice(list.get(which)))
                    .show();
        }
    }

    /** mp4 优先，其次 m3u8，其余按嗅探顺序。 */
    private List<SniffedVideo> sortedCandidates() {
        List<SniffedVideo> all = new ArrayList<>(found.values());
        all.sort((a, b) -> rank(a.url) - rank(b.url));
        return all;
    }

    private static int rank(String url) {
        String u = url.toLowerCase();
        if (u.contains(".mp4")) return 0;
        if (u.contains(".m3u8")) return 1;
        return 2;
    }

    private void castToDevice(SniffedVideo video) {
        webCastStatus.setText("正在投屏：" + shortUrl(video.url));
        String title = TextUtils.isEmpty(webView.getTitle()) ? "网页视频" : webView.getTitle();
        String playUrl = proxyUrl(video.url);
        new Thread(() -> {
            String err = controller.cast(device, playUrl, title, video.mime, "video", video.headers);
            runOnUiThread(() -> {
                if (err == null) {
                    webCastStatus.setText("已投放到 " + device.displayName());
                    Toast.makeText(this, "已投放到 " + device.displayName(), Toast.LENGTH_LONG).show();
                } else {
                    webCastStatus.setText("投屏失败：" + err);
                    Toast.makeText(this, "投屏失败：" + err, Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    /**
     * 把外网视频地址包成手机本地代理地址：盒子只访问局域网 http，
     * 由手机拉取外网流并转发，规避老盒子不支持 https 和 Referer 防盗链。
     */
    private String proxyUrl(String realUrl) {
        try {
            String ip = NetUtils.getLocalIpv4();
            if (ip == null) return realUrl;
            String ref = webView.getUrl();
            StringBuilder sb = new StringBuilder("http://")
                    .append(ip).append(':').append(HTTP_PORT)
                    .append("/proxy?url=").append(URLEncoder.encode(realUrl, "UTF-8"));
            if (ref != null && !ref.isEmpty()) {
                sb.append("&ref=").append(URLEncoder.encode(ref, "UTF-8"));
            }
            return sb.toString();
        } catch (Exception e) {
            return realUrl;
        }
    }

    private static String shortUrl(String url) {
        if (url == null) return "";
        return url.length() > 48 ? url.substring(0, 48) + "…" : url;
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }

    /** 一条嗅探到的视频地址及其请求头。 */
    private static class SniffedVideo {
        final String url;
        final String mime;
        final Map<String, String> headers;

        SniffedVideo(String url, String mime, Map<String, String> headers) {
            this.url = url;
            this.mime = mime;
            this.headers = headers;
        }
    }
}
