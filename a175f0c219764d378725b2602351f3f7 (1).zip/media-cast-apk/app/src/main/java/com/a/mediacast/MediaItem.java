package com.a.mediacast;

import android.net.Uri;

/**
 * 手机本地媒体条目。
 */
public class MediaItem {

    public final long id;
    public final String title;
    public final String mimeType;
    public final Uri uri;
    public final long size;
    public final long duration;
    public final String kind; // video / image / audio

    public MediaItem(long id, String title, String mimeType, Uri uri,
                     long size, long duration, String kind) {
        this.id = id;
        this.title = title;
        this.mimeType = mimeType;
        this.uri = uri;
        this.size = size;
        this.duration = duration;
        this.kind = kind;
    }

    @Override
    public String toString() {
        return title;
    }
}
