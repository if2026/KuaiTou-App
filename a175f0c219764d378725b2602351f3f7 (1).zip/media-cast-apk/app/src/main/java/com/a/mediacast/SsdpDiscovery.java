package com.a.mediacast;

import android.content.Context;
import android.net.wifi.WifiManager;
import android.os.Handler;
import android.os.Looper;
import android.util.Xml;

import org.xmlpull.v1.XmlPullParser;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.URL;
import java.util.HashSet;
import java.util.Set;

/**
 * SSDP/UPnP 发现局域网内的 DLNA 设备，拉取设备描述 XML，
 * 解析出 friendlyName、设备类型与 AVTransport / RenderingControl 控制地址。
 */
public class SsdpDiscovery {

    public interface Listener {
        void onDeviceFound(DmrDevice device);
        /** 一轮扫描结束（超时退出或异常结束），用于收尾提示。 */
        void onScanFinished();
    }

    private static final String GROUP = "239.255.255.250";
    private static final int PORT = 1900;
    private static final int TIMEOUT_MS = 3000;

    private final Set<String> seen = new HashSet<>();
    private final Handler main = new Handler(Looper.getMainLooper());
    private WifiManager.MulticastLock multicastLock;

    public void scan(Context ctx, Listener listener) {
        acquireLock(ctx);
        new Thread(() -> {
            DatagramSocket socket = null;
            try {
                socket = new DatagramSocket();
                socket.setSoTimeout(TIMEOUT_MS);
                InetAddress group = InetAddress.getByName(GROUP);

                String[] targets = {
                        "urn:schemas-upnp-org:device:MediaRenderer:1",
                        "urn:schemas-upnp-org:service:AVTransport:1",
                        "ssdp:all"
                };
                for (String st : targets) {
                    String msg = "M-SEARCH * HTTP/1.1\r\n"
                            + "HOST: " + GROUP + ":" + PORT + "\r\n"
                            + "MAN: \"ssdp:discover\"\r\n"
                            + "MX: 3\r\n"
                            + "ST: " + st + "\r\n\r\n";
                    DatagramPacket p = new DatagramPacket(msg.getBytes("UTF-8"),
                            msg.length(), group, PORT);
                    socket.send(p);
                }

                byte[] buf = new byte[8192];
                long deadline = System.currentTimeMillis() + TIMEOUT_MS;
                while (System.currentTimeMillis() < deadline) {
                    DatagramPacket p = new DatagramPacket(buf, buf.length);
                    try {
                        socket.receive(p);
                    } catch (Exception e) {
                        break;
                    }
                    String resp = new String(p.getData(), 0, p.getLength(), "UTF-8");
                    String location = header(resp, "LOCATION");
                    String usn = header(resp, "USN");
                    String server = header(resp, "SERVER");
                    if (location == null || usn == null) continue;
                    String auth = authority(location);
                    synchronized (seen) {
                        if (seen.contains(usn) || seen.contains(auth)) continue;
                        seen.add(usn);
                        seen.add(auth);
                    }
                    DmrDevice device = new DmrDevice(usn);
                    device.location = location;
                    device.serverHeader = server;
                    device.name = server;
                    parseDescription(device);
                    // 描述拉取失败或解析不出服务的通告直接丢弃，不进设备列表。
                    if (!device.isDiscoverable()) continue;
                    main.post(() -> listener.onDeviceFound(device));
                }
            } catch (Exception ignored) {
            } finally {
                if (socket != null) socket.close();
                releaseLock();
                main.post(() -> listener.onScanFinished());
            }
        }, "ssdp-scan").start();
    }

    private void parseDescription(DmrDevice device) {
        HttpURLConnection conn = null;
        InputStream is = null;
        try {
            URL url = new URL(device.location);
            conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(3000);
            conn.setReadTimeout(3000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", "MediaCast/1.0 UPnP/1.0 Android");
            is = conn.getInputStream();

            XmlPullParser parser = Xml.newPullParser();
            parser.setInput(is, "UTF-8");

            String svcType = null;
            String ctrlUrl = null;
            int event = parser.getEventType();
            while (event != XmlPullParser.END_DOCUMENT) {
                String tag = localName(parser.getName());
                if (event == XmlPullParser.START_TAG) {
                    if ("friendlyName".equals(tag)) {
                        device.name = parser.nextText();
                    } else if ("modelName".equals(tag)) {
                        device.modelName = parser.nextText();
                    } else if ("deviceType".equals(tag)) {
                        device.deviceType = parser.nextText();
                    } else if ("serviceType".equals(tag)) {
                        svcType = parser.nextText();
                    } else if ("controlURL".equals(tag)) {
                        ctrlUrl = parser.nextText();
                    }
                } else if (event == XmlPullParser.END_TAG && "service".equals(tag)) {
                    if (svcType != null) {
                        device.services = (device.services + shortSvc(svcType) + " ").trim();
                        if (ctrlUrl != null) {
                            String abs = new URL(new URL(device.location), ctrlUrl).toString();
                            if (svcType.contains("AVTransport")) {
                                device.avTransportUrl = abs;
                            } else if (svcType.contains("RenderingControl")) {
                                device.renderControlUrl = abs;
                            }
                        }
                    }
                    svcType = null;
                    ctrlUrl = null;
                }
                event = parser.next();
            }
            device.parseNote = device.services.isEmpty()
                    ? "描述中未列出可识别服务" : "已解析：" + device.services;
        } catch (Exception e) {
            String m = e.getMessage() == null ? "" : e.getMessage();
            String msg = e.getClass().getSimpleName() + (m.isEmpty() ? "" : ": " + m);
            device.parseNote = "描述解析失败：" + (msg.length() > 70 ? msg.substring(0, 70) : msg);
        } finally {
            try { if (is != null) is.close(); } catch (Exception ignored) {}
            if (conn != null) conn.disconnect();
        }
    }

    private static String localName(String tag) {
        if (tag == null) return null;
        int idx = tag.indexOf(':');
        return idx >= 0 ? tag.substring(idx + 1) : tag;
    }

    private static String shortSvc(String t) {
        if (t.contains("AVTransport")) return "AVTransport";
        if (t.contains("RenderingControl")) return "RenderingControl";
        if (t.contains("ConnectionManager")) return "ConnectionManager";
        int i = t.lastIndexOf(':');
        return i >= 0 ? t.substring(i + 1) : t;
    }

    /** 取描述 URL 的 host:port，用于把同一设备的多条通告合并成一条。 */
    private static String authority(String location) {
        try {
            URL u = new URL(location);
            int port = u.getPort() == -1 ? u.getDefaultPort() : u.getPort();
            return u.getHost() + ":" + port;
        } catch (Exception e) {
            return location;
        }
    }

    private static String header(String response, String key) {
        for (String line : response.split("\r\n")) {
            int idx = line.indexOf(':');
            if (idx > 0 && line.substring(0, idx).trim().equalsIgnoreCase(key)) {
                return line.substring(idx + 1).trim();
            }
        }
        return null;
    }

    private void acquireLock(Context ctx) {
        try {
            WifiManager wm = (WifiManager) ctx.getApplicationContext()
                    .getSystemService(Context.WIFI_SERVICE);
            if (wm != null) {
                multicastLock = wm.createMulticastLock("mediacast-ssdp");
                multicastLock.setReferenceCounted(false);
                multicastLock.acquire();
            }
        } catch (Exception ignored) {
        }
    }

    private void releaseLock() {
        if (multicastLock != null && multicastLock.isHeld()) {
            multicastLock.release();
        }
    }
}
