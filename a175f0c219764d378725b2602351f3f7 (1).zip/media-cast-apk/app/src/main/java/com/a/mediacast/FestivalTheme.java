package com.a.mediacast;

import android.graphics.Color;

import java.util.Calendar;

/**
 * 节日彩蛋主题：按系统日期判断圣诞 / 春节，只改代码颜色与文字，不引入图片资源。
 * 非节日返回 NONE，界面保持默认深色极简风格。
 */
public final class FestivalTheme {

    private FestivalTheme() {}

    public enum Festival {
        NONE, CHRISTMAS, SPRING
    }

    /**
     * 春节正月初一公历日期表（已核对）。表内年份按初一到初七（7 天）判定为春节期间；
     * 表外年份不触发，需要时在此数组续加 {年, 月, 日}。
     */
    private static final int[][] SPRING_FIRST = {
            {2025, 1, 29},
            {2026, 2, 17},
            {2027, 2, 6},
            {2028, 1, 26},
            {2029, 2, 13},
            {2030, 2, 3},
            {2031, 1, 23},
            {2032, 2, 11},
            {2033, 1, 31},
            {2034, 2, 19},
            {2035, 2, 8}
    };

    private static final int SPRING_DAYS = 7;

    public static Festival today() {
        Calendar now = Calendar.getInstance();
        int month = now.get(Calendar.MONTH); // 0-based
        int day = now.get(Calendar.DAY_OF_MONTH);

        if (month == Calendar.DECEMBER && (day == 24 || day == 25)) {
            return Festival.CHRISTMAS;
        }
        if (isSpringFestival(now)) {
            return Festival.SPRING;
        }
        return Festival.NONE;
    }

    private static boolean isSpringFestival(Calendar now) {
        long today = now.getTimeInMillis();
        for (int[] f : SPRING_FIRST) {
            Calendar first = Calendar.getInstance();
            first.set(f[0], f[1] - 1, f[2], 0, 0, 0);
            first.set(Calendar.MILLISECOND, 0);
            long diff = (today - first.getTimeInMillis()) / (24L * 60 * 60 * 1000);
            if (diff >= 0 && diff < SPRING_DAYS) return true;
        }
        return false;
    }

    /** 节日主强调色（圣诞红 / 春节深红）。 */
    public static int primaryColor(Festival f) {
        switch (f) {
            case CHRISTMAS: return Color.parseColor("#E23B3B");
            case SPRING: return Color.parseColor("#B3261E");
            default: return Color.TRANSPARENT;
        }
    }

    /** 节日辅助色（圣诞绿 / 春节金）。 */
    public static int secondaryColor(Festival f) {
        switch (f) {
            case CHRISTMAS: return Color.parseColor("#2E9E5B");
            case SPRING: return Color.parseColor("#E8B33C");
            default: return Color.TRANSPARENT;
        }
    }

    public static String title(Festival f) {
        switch (f) {
            case CHRISTMAS: return "圣诞快乐";
            case SPRING: return "新年快乐";
            default: return "";
        }
    }

    public static String greeting(Festival f) {
        switch (f) {
            case CHRISTMAS: return "圣诞快乐！极限工具箱陪你投出精彩";
            case SPRING: return "新年快乐，祝你投屏不卡顿";
            default: return "";
        }
    }
}
