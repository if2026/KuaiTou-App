package com.a.mediacast;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URL;
import java.net.URLDecoder;
import java.util.HashMap;
import java.util.Map;

/**
 * 极简局域网 HTTP 服务：把本地媒体通过 /media/<kind>/<id> 暴露给电视/盒子拉取。
 * 支持 Range 分段请求，便于视频拖动与流式播放。
 */
public class MediaHttpServer {

    private final Context ctx;
    private final int port;
    private ServerSocket socket;
    private Thread thread;
    private volatile boolean running;

    public MediaHttpServer(Context ctx, int port) {
        this.ctx = ctx.getApplicationContext();
        this.port = port;
    }

    public String baseUrl() {
        String ip = NetUtils.getLocalIpv4();
        return "http://" + (ip == null ? "127.0.0.1" : ip) + ":" + port;
    }

    public String urlFor(MediaItem item) {
        return baseUrl() + "/media/" + item.kind + "/" + item.id;
    }

    public void start() {
        running = true;
        thread = new Thread(() -> {
            try {
                socket = new ServerSocket(port);
                while (running) {
                    Socket s = socket.accept();
                    try {
                        handle(s);
                    } catch (Exception ignored) {
                    } finally {
                        try { s.close(); } catch (Exception ignored) {}
                    }
                }
            } catch (Exception ignored) {
            }
        }, "media-http-server");
        thread.start();
    }

    public void stop() {
        running = false;
        try { if (socket != null) socket.close(); } catch (Exception ignored) {}
        if (thread != null) thread.interrupt();
    }

    private void handle(Socket s) throws Exception {
        BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
        String reqLine = in.readLine();
        if (reqLine == null || !reqLine.startsWith("GET ")) return;

        String range = null;
        String line;
        while ((line = in.readLine()) != null && !line.isEmpty()) {
            if (line.toLowerCase().startsWith("range:")) {
                range = line.substring(line.indexOf(':') + 1).trim();
            }
        }

        String target = reqLine.split(" ")[1];
        String pathPart = target;
        String query = null;
        int qMark = target.indexOf('?');
        if (qMark >= 0) {
            pathPart = target.substring(0, qMark);
            query = target.substring(qMark + 1);
        }
        String[] seg = pathPart.split("/");
        // /proxy?url=... 外网视频本地中转；/media/<kind>/<id> 本地媒体
        if (seg.length >= 2 && "proxy".equals(seg[1])) {
            handleProxy(s, query, range);
            return;
        }
        // 形如 /media/video/123
        if (seg.length < 4) return;
        String kind = seg[2];
        long id;
        try {
            id = Long.parseLong(seg[3]);
        } catch (NumberFormatException e) {
            return;
        }

        Uri base;
        switch (kind) {
            case "video": base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI; break;
            case "image": base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI; break;
            case "audio": base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI; break;
            default: return;
        }
        Uri uri = Uri.withAppendedPath(base, String.valueOf(id));

        AssetFileDescriptor afd = null;
        long len;
        try {
            afd = ctx.getContentResolver().openAssetFileDescriptor(uri, "r");
            if (afd == null) return;
            len = afd.getLength();
        } finally {
            if (afd != null) afd.close();
        }

        long start = 0;
        long end = len - 1;
        boolean partial = false;
        if (range != null && range.startsWith("bytes=")) {
            String[] rr = range.substring(6).split("-");
            try {
                start = Long.parseLong(rr[0]);
                if (rr.length > 1 && !rr[1].isEmpty()) end = Long.parseLong(rr[1]);
                partial = true;
            } catch (NumberFormatException ignored) {
                start = 0; end = len - 1;
            }
        }
        if (end >= len) end = len - 1;
        if (start > end) return;
        long length = end - start + 1;

        String mime = resolveMime(uri, kind);
        OutputStream out = s.getOutputStream();
        StringBuilder head = new StringBuilder();
        head.append("HTTP/1.1 ").append(partial ? "206 Partial Content" : "200 OK").append("\r\n");
        head.append("Content-Type: ").append(mime).append("\r\n");
        head.append("Content-Length: ").append(length).append("\r\n");
        head.append("Accept-Ranges: bytes\r\n");
        if (partial) {
            head.append("Content-Range: bytes ").append(start).append("-").append(end)
                    .append("/").append(len).append("\r\n");
        }
        // DLNA/UPnP 媒体源识别头，部分电视固件缺少这些头会拒绝播放
        head.append("transferMode.dlna.org: Streaming\r\n");
        head.append("contentFeatures.dlna.org:\r\n");
        head.append("realTimeInfo.dlna.org: DLNA.ORG_TLAG=*\r\n");
        head.append("Server: DLNADOC/1.50 UPnP/1.0 MediaCast/1.0\r\n");
        head.append("Connection: close\r\n\r\n");
        out.write(head.toString().getBytes("UTF-8"));

        InputStream is = null;
        try {
            is = ctx.getContentResolver().openInputStream(uri);
            if (is == null) return;
            long skipped = 0;
            while (skipped < start) skipped += is.skip(start - skipped);
            byte[] buf = new byte[64 * 1024];
            long remaining = length;
            while (remaining > 0) {
                int n = is.read(buf, 0, (int) Math.min(buf.length, remaining));
                if (n < 0) break;
                out.write(buf, 0, n);
                remaining -= n;
            }
            out.flush();
        } finally {
            if (is != null) is.close();
        }
    }

    private static final String PROXY_UA = "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 "
            + "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36";

    /**
     * 外网视频本地中转：盒子只访问手机局域网 http 代理，由手机拉取外网流并转发。
     * 解决老盒子不支持 https 取流、以及站点 Referer 防盗链的问题；Range 透传支持拖动。
     */
    private void handleProxy(Socket s, String query, String range) {
        Map<String, String> qm = parseQuery(query);
        String target = qm.get("url");
        String referer = qm.get("ref");
        if (target == null) return;

        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(target).openConnection();
            conn.setConnectTimeout(8000);
            conn.setReadTimeout(15000);
            conn.setInstanceFollowRedirects(true);
            conn.setRequestProperty("User-Agent", PROXY_UA);
            if (referer != null && !referer.isEmpty()) {
                conn.setRequestProperty("Referer", referer);
            }
            if (range != null && !range.isEmpty()) {
                conn.setRequestProperty("Range", range);
            }

            int code = conn.getResponseCode();
            String contentType = conn.getContentType();
            if (contentType == null || contentType.isEmpty()) contentType = "video/mp4";
            long length = conn.getContentLengthLong();
            String contentRange = conn.getHeaderField("Content-Range");

            InputStream upstream = code >= 400 ? conn.getErrorStream() : conn.getInputStream();
            OutputStream out = s.getOutputStream();

            StringBuilder head = new StringBuilder();
            head.append("HTTP/1.1 ").append(code).append(' ').append(statusText(code)).append("\r\n");
            head.append("Content-Type: ").append(contentType).append("\r\n");
            if (length >= 0) head.append("Content-Length: ").append(length).append("\r\n");
            head.append("Accept-Ranges: bytes\r\n");
            if (contentRange != null) head.append("Content-Range: ").append(contentRange).append("\r\n");
            head.append("Connection: close\r\n\r\n");
            out.write(head.toString().getBytes("UTF-8"));

            if (upstream != null) {
                byte[] buf = new byte[64 * 1024];
                int n;
                while ((n = upstream.read(buf)) != -1) {
                    out.write(buf, 0, n);
                }
                out.flush();
            }
        } catch (Exception ignored) {
        } finally {
            if (conn != null) conn.disconnect();
            try { s.close(); } catch (Exception ignored) {}
        }
    }

    private static Map<String, String> parseQuery(String query) {
        Map<String, String> out = new HashMap<>();
        if (query == null || query.isEmpty()) return out;
        try {
            for (String pair : query.split("&")) {
                int i = pair.indexOf('=');
                if (i > 0) {
                    out.put(URLDecoder.decode(pair.substring(0, i), "UTF-8"),
                            URLDecoder.decode(pair.substring(i + 1), "UTF-8"));
                }
            }
        } catch (Exception ignored) {
        }
        return out;
    }

    private static String statusText(int code) {
        if (code == 200) return "OK";
        if (code == 206) return "Partial Content";
        if (code == 403) return "Forbidden";
        if (code == 404) return "Not Found";
        return "HTTP";
    }

    private String resolveMime(Uri uri, String kind) {
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(uri,
                    new String[]{MediaStore.MediaColumns.MIME_TYPE}, null, null, null);
            if (c != null && c.moveToFirst()) {
                String m = c.getString(0);
                if (m != null && !m.isEmpty()) return m;
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return defaultMime(kind);
    }

    private String defaultMime(String kind) {
        switch (kind) {
            case "video": return "video/mp4";
            case "image": return "image/jpeg";
            case "audio": return "audio/mpeg";
            default: return "application/octet-stream";
        }
    }
}
