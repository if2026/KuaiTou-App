package com.a.mediacast;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.InputStream;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * 媒体列表适配器。
 * - 内存 LRU 缓存缩略图，滑出再滑回直接命中，不重复解码；
 * - 按 ImageView 实际边长降采样，不加载原图，避免大图撑爆内存；
 * - 快速滑动（Fling）时暂停加载，停稳后再补载当前可见项。
 */
public class MediaAdapter extends BaseAdapter {

    private static final int THUMB_DP = 56;

    private final Context ctx;
    private final List<MediaItem> items;
    private final LayoutInflater inflater;
    private final LruCache<String, Bitmap> cache;
    private final ExecutorService pool = Executors.newFixedThreadPool(2);
    private final Handler main = new Handler(Looper.getMainLooper());
    private final int defaultThumbPx;

    /** 列表是否正在快速/拖动滚动；为 true 时不排队加载缩略图。 */
    private volatile boolean scrolling = false;

    public MediaAdapter(Context ctx, List<MediaItem> items) {
        this.ctx = ctx;
        this.items = items;
        this.inflater = LayoutInflater.from(ctx);
        this.defaultThumbPx = (int) (THUMB_DP * ctx.getResources().getDisplayMetrics().density);
        int mem = (int) (Runtime.getRuntime().maxMemory() / 8);
        this.cache = new LruCache<String, Bitmap>(mem) {
            @Override
            protected int sizeOf(String key, Bitmap value) {
                return value.getByteCount();
            }
        };
    }

    /** 由列表滚动监听调用：滚动中传 true，停稳传 false。 */
    public void setScrolling(boolean scrolling) {
        this.scrolling = scrolling;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public Object getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return items.get(position).id;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder h;
        if (convertView == null) {
            convertView = inflater.inflate(R.layout.item_media, parent, false);
            h = new ViewHolder();
            h.thumb = convertView.findViewById(R.id.thumb);
            h.title = convertView.findViewById(R.id.media_title);
            h.sub = convertView.findViewById(R.id.media_sub);
            convertView.setTag(h);
        } else {
            h = (ViewHolder) convertView.getTag();
        }

        MediaItem item = items.get(position);
        h.itemId = item.id;
        h.title.setText(nameOf(item));
        h.sub.setText(subtitle(item));

        String key = cacheKey(item);
        Bitmap cached = cache.get(key);
        if (cached != null) {
            h.thumb.setImageBitmap(cached);
        } else {
            h.thumb.setImageResource(placeholderRes(item.kind));
            // 滚动中不加载，停稳后由列表回调 notifyDataSetChanged 再补载。
            if (!scrolling) {
                int target = Math.max(h.thumb.getWidth(), h.thumb.getHeight());
                if (target <= 0) target = defaultThumbPx;
                loadThumb(h, item, target);
            }
        }
        return convertView;
    }

    private void loadThumb(ViewHolder h, MediaItem item, int targetPx) {
        pool.execute(() -> {
            Bitmap bmp = null;
            try {
                if ("image".equals(item.kind)) {
                    bmp = decodeImage(item.uri, targetPx);
                } else if ("video".equals(item.kind)) {
                    bmp = decodeVideoFrame(item.uri, targetPx);
                }
            } catch (Exception ignored) {
            }
            if (bmp != null) cache.put(cacheKey(item), bmp);
            Bitmap result = bmp;
            main.post(() -> {
                // 复用导致条目已变时不回写，避免串图
                if (h.itemId != item.id) return;
                if (result != null) h.thumb.setImageBitmap(result);
                else h.thumb.setImageResource(placeholderRes(item.kind));
            });
        });
    }

    private Bitmap decodeImage(Uri uri, int targetPx) {
        BitmapFactory.Options opts = new BitmapFactory.Options();
        opts.inJustDecodeBounds = true;
        InputStream in = null;
        try {
            in = ctx.getContentResolver().openInputStream(uri);
            BitmapFactory.decodeStream(in, null, opts);
            close(in);
            opts.inSampleSize = sampleSize(opts.outWidth, opts.outHeight, targetPx);
            opts.inJustDecodeBounds = false;
            in = ctx.getContentResolver().openInputStream(uri);
            Bitmap bmp = BitmapFactory.decodeStream(in, null, opts);
            return scaleDown(bmp, targetPx);
        } catch (Exception e) {
            return null;
        } finally {
            close(in);
        }
    }

    private Bitmap decodeVideoFrame(Uri uri, int targetPx) {
        MediaMetadataRetriever retriever = new MediaMetadataRetriever();
        try {
            retriever.setDataSource(ctx, uri);
            Bitmap frame = retriever.getFrameAtTime(0,
                    MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
            if (frame == null) frame = retriever.getFrameAtTime();
            return scaleDown(frame, targetPx);
        } catch (Exception e) {
            return null;
        } finally {
            try { retriever.release(); } catch (Exception ignored) {}
        }
    }

    /** 按目标边长取 2 的幂降采样，先粗采样再精细缩放，避免直接读原图。 */
    private static int sampleSize(int w, int h, int target) {
        int size = 1;
        int max = Math.max(w, h);
        while (max / size > target * 2) size *= 2;
        return size;
    }

    private static Bitmap scaleDown(Bitmap src, int target) {
        if (src == null) return null;
        int w = src.getWidth();
        int h = src.getHeight();
        int max = Math.max(w, h);
        if (max <= target) return src;
        float ratio = (float) target / max;
        return Bitmap.createScaledBitmap(src, (int) (w * ratio), (int) (h * ratio), true);
    }

    private static String cacheKey(MediaItem item) {
        return item.kind + "#" + item.id;
    }

    private static String nameOf(MediaItem item) {
        if (item.title == null || item.title.isEmpty()) return "（未命名）";
        return item.title;
    }

    private String subtitle(MediaItem m) {
        StringBuilder sb = new StringBuilder();
        sb.append(formatSize(m.size));
        if (m.duration > 0) sb.append(" · ").append(formatDuration(m.duration));
        if (m.mimeType != null && m.mimeType.contains("/")) {
            sb.append(" · ").append(m.mimeType.substring(m.mimeType.lastIndexOf('/') + 1));
        }
        return sb.toString();
    }

    private static String formatSize(long bytes) {
        if (bytes <= 0) return "未知大小";
        if (bytes < 1024) return bytes + " B";
        if (bytes < 1024 * 1024) return String.format("%.1f KB", bytes / 1024.0);
        if (bytes < 1024 * 1024 * 1024) return String.format("%.1f MB", bytes / 1024.0 / 1024.0);
        return String.format("%.2f GB", bytes / 1024.0 / 1024.0 / 1024.0);
    }

    private static String formatDuration(long ms) {
        long sec = ms / 1000;
        long mm = sec / 60;
        long ss = sec % 60;
        return String.format("%02d:%02d", mm, ss);
    }

    private static int placeholderRes(String kind) {
        if ("video".equals(kind)) return R.drawable.ic_video;
        if ("image".equals(kind)) return R.drawable.ic_image;
        return R.drawable.ic_audio;
    }

    private static void close(InputStream in) {
        try { if (in != null) in.close(); } catch (Exception ignored) {}
    }

    private static class ViewHolder {
        ImageView thumb;
        TextView title;
        TextView sub;
        long itemId;
    }
}
