package com.a.mediacast;

import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.List;

/** 从 MediaStore 读取本地视频 / 图片 / 音频，支持分页（offset / limit）懒加载。 */
public final class MediaStoreReader {

    private MediaStoreReader() {}

    /**
     * 按 MIME 类型过滤：系统媒体表偶尔会把其他类型文件登记进来
     * （例如含音轨的 mp4 出现在音频表）。MIME 为空时保留，避免误删。
     */
    private static boolean mimeMatches(String kind, String mime) {
        if (mime == null) return true;
        String m = mime.toLowerCase();
        switch (kind) {
            case "video":
                return !m.startsWith("audio/") && !m.startsWith("image/");
            case "image":
                return !m.startsWith("video/") && !m.startsWith("audio/");
            case "audio":
            default:
                return !m.startsWith("video/") && !m.startsWith("image/");
        }
    }

    /**
     * 读取一批媒体。
     * @param offset 跳过前面多少条
     * @param limit  本批最多取多少条
     */
    public static List<MediaItem> loadPage(Context ctx, String kind, int offset, int limit) {
        List<MediaItem> out = new ArrayList<>();
        Uri base;
        String[] projection;
        String sort;
        String actualKind = kind;

        switch (kind) {
            case "video":
                base = MediaStore.Video.Media.EXTERNAL_CONTENT_URI;
                projection = new String[] {
                        MediaStore.Video.Media._ID,
                        MediaStore.Video.Media.TITLE,
                        MediaStore.Video.Media.MIME_TYPE,
                        MediaStore.Video.Media.SIZE,
                        MediaStore.Video.Media.DURATION
                };
                sort = MediaStore.Video.Media.DATE_ADDED + " DESC";
                break;
            case "image":
                base = MediaStore.Images.Media.EXTERNAL_CONTENT_URI;
                projection = new String[] {
                        MediaStore.Images.Media._ID,
                        MediaStore.Images.Media.TITLE,
                        MediaStore.Images.Media.MIME_TYPE,
                        MediaStore.Images.Media.SIZE
                };
                sort = MediaStore.Images.Media.DATE_ADDED + " DESC";
                break;
            case "audio":
            default:
                base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
                projection = new String[] {
                        MediaStore.Audio.Media._ID,
                        MediaStore.Audio.Media.TITLE,
                        MediaStore.Audio.Media.MIME_TYPE,
                        MediaStore.Audio.Media.SIZE,
                        MediaStore.Audio.Media.DURATION
                };
                sort = MediaStore.Audio.Media.DATE_ADDED + " DESC";
                actualKind = "audio";
                break;
        }

        // sortOrder 只传纯排序字段；LIMIT/OFFSET 子句在部分 ROM 的 MediaStore 上
        // 不被接受会返回空游标，分页改由游标 moveToPosition 定位后分批读取。
        Cursor c = null;
        try {
            c = ctx.getContentResolver().query(base, projection, null, null, sort);
            if (c == null) return out;
            int idCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns._ID);
            int titleCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.TITLE);
            int mimeCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.MIME_TYPE);
            int sizeCol = c.getColumnIndexOrThrow(MediaStore.MediaColumns.SIZE);
            int durCol = c.getColumnIndex(MediaStore.MediaColumns.DURATION);

            int start = Math.max(0, offset);
            if (!c.moveToPosition(start)) return out;
            int count = 0;
            do {
                long id = c.getLong(idCol);
                String title = c.getString(titleCol);
                String mime = c.getString(mimeCol);
                long size = c.getLong(sizeCol);
                long dur = durCol >= 0 ? c.getLong(durCol) : 0;
                if (!mimeMatches(actualKind, mime)) continue;
                Uri uri = Uri.withAppendedPath(base, String.valueOf(id));
                out.add(new MediaItem(id, title, mime, uri, size, dur, actualKind));
                count++;
            } while (count < limit && c.moveToNext());
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return out;
    }
}
